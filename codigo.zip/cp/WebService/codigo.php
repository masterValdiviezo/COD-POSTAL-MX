<?php
header('Content-Type: text/html; charset=UTF-8');
//header('Content-Type: text/html; charset=ISO-8859-1');
?>
<head>
<!--- <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>-->
</head>
<body>

<?php
$codigo = $_POST['valor1'];

//echo '<script>alert('.$codigo. ');</script>';

$options = array('http' => array(
'method'  => 'POST',
));

$config= stream_context_create($options);

$buscar = 'https://tucodigo.mx/index.php?cp='.$codigo;    /// actualizado hoy maestro 21-09-2021
//// $buscar = 'https://www.codigo-postal.mx/buscar/?estado=&q='.$codigo;
/// $buscar = 'http://micodigopostal.org/buscarcp.php?buscar='.$codigo;



$config_final=file_get_contents($buscar,false, $config);
preg_match_all('|<center>(.*)</center>|sU', $config_final, $tiempo);
///// preg_match_all('|<section style="height: auto !important;">(.*)</table>|sU', $config_final, $tiempo);
if(isset($tiempo[1][0]))
{	
echo $tiempo[1][0];
}
else
{
     $tiempo[1][0] = 'N/E';
echo $tiempo[1][0];
}	
?>
<!--
<div id="arrData">
<strong>Resultado Obtenido</strong><br/>
</div>
--->

<!-- <input id="resultado" name="resultado" size="500" type="text" value="">  -->

<!--  <input id="resultado2" name="resultado2" size="800" type="text" value=""> --->
</body>
</html>
<script>
$(document).ready(function () {
$("#arrData").hide();
//alert('que onda JVS');
            $('tr').click(function () {
                var tableData = $(this).children('td').map(function () {
                    return $(this).text();
                }).get();
                var props = $('thead > tr th');
                var array = [];
                props.each(function () { array.push($(this).text()) });
                //keys
                console.log(array);
                //values
                console.log(tableData);

                var obj = {};
                for (var i = 0; i < tableData.length; i++) {
                    obj[array[i]] = tableData[i];
                }
                console.log(obj);
            });
				
var array_datos = [];	
var num = 0;	
$('tr').each(function () {
var Colonia = $(this).find("td").eq(0).text();
var Delegacion = $(this).find("td").eq(1).text();
var Ciudad = $(this).find("td").eq(2).text();
var Estado = $(this).find("td").eq(3).text();
var  Cola = Colonia + '*' + Delegacion+ '*' + Ciudad + '*' + Estado;
array_datos[num] = Cola;
console.log(Cola);

num = num + 1;

});		

array_datos = array_datos.slice(0);		
array_datos = array_datos.slice(1);	
var  juntos = "";
        jQuery.each(array_datos, function(j, val) {
		  $("#arrData").append(j + " : " + val + "<br/>");	
     
                 juntos = juntos + "//jvs//" + val;	

		});	
		
		
//console.log(juntos);
//console.log(num);	
$('#resultado').val(juntos);

            // puse esto hoy 11 enero 2016
//juntos = $('#resultado2').val();
//juntos = juntos.replace('Postal:','',juntos);

var largo = juntos.length;
//juntos = juntos.substring(10,largo);

//convertimos una cadena en array
  var array_ciudades = juntos.split("//jvs//");

//$('#resultado2').val(lista[0]);
var largo_array = array_ciudades.length;
var limite = largo_array;

//$("#jvs").remove();
$('#jvs option').remove();

var k = 0;
for (var i=2; i < limite; i++){
 k++;
$('#resultado2').val(array_ciudades[i]);

var localidades = array_ciudades[i].split("*");

localidades[0] = localidades[0].toUpperCase();

$('#delegacion').val(localidades[1].toUpperCase());
$('#ciudad').val(localidades[2].toUpperCase());
$('#estado').val(localidades[3].toUpperCase());

$('#jvs').append('<option value="'+localidades[0]+'" >'+localidades[0]+'</option>');
}

if(k == 0)
{
$('#delegacion').val('');
$('#ciudad').val('');
$('#estado').val('');

}

$("#codigo").change(function(){
	  document.title = 'JM';
      
	  //$('#liga').click();
	  $('#go').click();
     });



        });
</script>

