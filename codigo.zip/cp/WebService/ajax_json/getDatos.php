
<html>
<title>obteniendo Datos del Codigo Postal</title>
<head>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
</head>
<body>

<div>
<?php
$options = array('http' => array(
'method'  => 'GET',
));

$config= stream_context_create($options);
$buscar = 'http://tucodigo.mx/index.php?cp=70300';
$config_final=file_get_contents($buscar,false, $config);
preg_match_all('|<center>(.*)</center>|sU', $config_final, $tiempo);
echo $tiempo[1][0];

?>
</div>


<div id="arrData">
<strong>Array</strong><br/>
</div>


</body>
</html>

<script>
$(document).ready(function () {
alert('que onda JVS');
            $('tr').click(function () {
                var tableData = $(this).children('td').map(function () {
                    return $(this).text();
                }).get();
                var props = $('thead > tr th');
                var array = [];
                props.each(function () { array.push($(this).text()) });
                //keys
                console.log(array);
                //values
                console.log(tableData);

                var obj = {};
                for (var i = 0; i < tableData.length; i++) {
                    obj[array[i]] = tableData[i];
                }
                console.log(obj);
            });
				
var array_datos = [];	
var num = 0;	
        $('tr').each(function () {
var Colonia = $(this).find("td").eq(0).text();
var Delegacion = $(this).find("td").eq(1).text();
var Ciudad = $(this).find("td").eq(2).text();
var Estado = $(this).find("td").eq(3).text();
var  Cola = Colonia + '*' + Delegacion+ '*' + Ciudad + '*' + Estado;
array_datos[num] = Cola;
console.log(Cola);
num = num + 1;

});		

array_datos = array_datos.slice(0);		
array_datos = array_datos.slice(1);	

        jQuery.each(array_datos, function(j, val) {
		  $("#arrData").append(j + " : " + val + "<br/>");		  
		});	
		
console.log(num);
var obj = array_datos;
echo json_encode(obj);
		

        });
</script>