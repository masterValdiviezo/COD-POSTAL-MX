<?php
echo $_GET['paquete'];

echo "<br><br>saludos JM-210921";
?>
