<?php
/// Llenar Campos desde el codigo postal(MX)
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta name="google" content="notranslate" />	
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>LLENAR CAMPOS</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script>
function justNumbers(e)
{
var keynum = window.event ? window.event.keyCode : e.which;
if ((keynum == 8) || (keynum == 46))
return true;
return /\d/.test(String.fromCharCode(keynum));
}	
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 		
</head>
<body translate="no">
<h3>COD. POSTAL(MX)</h3>
 <div class="Cell">  
<p>  
<label>Código Postal:</label>
<label> <input onkeypress="return justNumbers(event);"  maxlength="8" class="texto" type="text" id="codigo" name="codigo" size="8" value=""  required="required" title="Doble clic aqui si no Visualiza localidades " /></label>
</p>
</div>  
<div class="Row">   
<p>	
<label align="right" nowrap="nowrap">Localidad:</label>
<label>
<select id="jvs" name="jvs">
<option value="" ></option>	
</select>
</label>
</p>  
</div>  

<div class="Row">  
<p>  
 <label align="right" nowrap="nowrap">Municipio/<br>Delegación:</label> 
<label>
<input style="text-transform:uppercase;" required="required" class="texto" type="text" id="delegacion" name="delegacion" size="30" value="<?php echo $mis_datos['municipio']; ?>"  />
</label>
</p>  
</div>  
	
<div class="Row">  
<p>  
<label align="right" nowrap="nowrap">Ciudad:</label> 
<label>
<input style="text-transform:uppercase;"  class="texto" type="text" id="ciudad" name="ciudad" size="30" value="<?php echo $mis_datos['ciudad']; ?>"  />
</label>
</p>  
</div>  

	
<div class="Row">  
<p>  
<label>Estado:</label> 
<label> <input style="text-transform:uppercase;" required="required" class="texto" type="text" id="estado" name="estado" size="30" value="<?php echo $mis_datos['estado']; ?>"  /></label>
</p>  
</div> 
<div id="capa1"></div>
</body>
</html>
<script>		
$(document).ready(function(){
$("#codigo").dblclick(function(){	
$("#jvs").empty();	
            var postal2 = $('input[name=codigo]').val();
alert('...Buscando el Código Postal: '+postal2);
$("#capa1").load("WebService/codigo.php",{valor1:postal2}, function(response, status, xhr) {
						  if (status == "error") {
						    var msg2 = "Error!, algo ha sucedido: ";
						    $("#capa1").html(msg2 + xhr.status + " " + xhr.statusText);
						  }
						});
        $('#capa1').hide();	
});	

$("#codigo").change(function(){
$("#jvs").empty();	
            var postal = $('input[name=codigo]').val();
//alert('...Buscando el Código Postal: '+postal);
$("#capa1").load("WebService/codigo.php",{valor1:postal}, function(response, status, xhr) {
						  if (status == "error") {
						    var msg2 = "Error!, algo ha sucedido: ";
						    $("#capa1").html(msg2 + xhr.status + " " + xhr.statusText);
						  }
	
///alert(response);	
var elem_combo = $("#jvs").length;
//// alert('# ' + elem_combo);
	
	
						});
        $('#capa1').hide();	

});
			
		
});
</script>